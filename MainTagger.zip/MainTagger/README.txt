Together with ChatGPT I created a little addon for Turtle-wow that will print your Main character name in Guild chat if you are on an Alt or have some fun if you are on your main. 
If your guild uses  pfUI-autoinvite (https://github.com/BahamutxD/pfUI-autoinvite)  than you can set the string to prevent the changing of the chat message so auto invite works.

Version: 1.1 
Initial release

Version: 2.0
The Main name and Main class are now stored per character and not per account.
You can now set you mainname and mainclass per Alt (for those that want some fun on their main or are in different guilds with different alts). 

You have to set it for every alt.

Version: 2.1
Typing 123 in Guildchat skips the code so you can use it to get a raid invite.

Version: 2.2
Now there is configuration screen. Just type /mtc or /maintaggerconfig

Version: 2.3
Fixed a bug where MainTagger was blocking the basic WoW slash commands

Version 2.4
Fixed a bug where the 123 raid invite did not work anymore.
Added a field where you can set the auto raid invite command if you use pfui autoinvite.

Version 2.5
Now the name of your Main is also shown when you whisper someone.

Installation:
Shutdown your wow client.
Unzip MainTagger in your Addons folder

Commands:
/mtc 
/maintaggerconfig
/mainname YourMainCharacterName
/mainclass YourMainCharacterClass

Now if you send a message in guild chat it will add your main character name in the chat. 

